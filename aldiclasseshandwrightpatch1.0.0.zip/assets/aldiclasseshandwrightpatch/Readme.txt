You found me be the real treasure is the friends you made on the way!

Jokes aside, this is an empty file that does nothing.
All Patches now sit in the main mod unter aldicalsses/compatibility/{patch name}
This makes the maintanance even more simple than before but now you need the latest version of the main mod for the Patches to work (at least 1.14.0)
This also means small bug fixes in Patch Mods will happen in the main Mod.

In the end it means: just update the main mod when a Patch Mod has a bug