#version 330

in vec2 vUV;

uniform sampler2D fragDepth;
//uniform sampler2D csOrig;

uniform float zNear = 0.1;
uniform float zFar = 1500.0;

layout(location = 0) out vec4 lDepth;


// From fogandlight.fsh, but keep in zFar to match csOrig
float linearDepth(float depthSample)
{
    depthSample = 2.0 * depthSample - 1.0;
    float zLinear = 2.0 * zNear * zFar / (zFar + zNear - depthSample * (zFar - zNear));
    return zLinear;
}

void main()
{
    float frag = texture(fragDepth, vUV).x;
    //float water = texture(csOrig, vUV).z;

    // Without liquid depth waterfalls won't be detected by rays, but they don't match exactly
    //lDepth = vec4(vec3(min(liquid, linearDepth(frag)), 1);

    lDepth = vec4(vec3(linearDepth(frag)), 1);
}
