#version 430

in vec2 vUV;
in vec3 eyeDirection;

layout(binding=0, rgba32f) restrict readonly uniform image2D cloudmap;
layout(binding=1, rgba16f) restrict uniform image2D cloudmapMip;
layout(binding=2, r16f) uniform image2D cloudshadowmarch;
layout(binding=3, r16f) uniform image2D cloudshadowmap;
layout(binding=4, r16f) uniform image2D cloudshadowprocessing;

layout(binding=5, rgba16f) uniform image2D debugtex;

uniform int cloudShadowsEnabled;

uniform sampler2D sceneDepth;

//uniform float zNear = 0.1;
//uniform float zFar = 1500.;

uniform float debug;

layout(location=0) out vec4 texColor;

/*
float linearDepth(float depthSample)
{
    depthSample = 2.0 * depthSample - 1.0;
    float zLinear = 2.0 * zNear * zFar / (zFar + zNear - depthSample * (zFar - zNear));
    return zLinear;
}
*/

void main() {
    ivec2 texPos = ivec2(gl_FragCoord.xy);
    /*
    float depth = linearDepth(texelFetch(sceneDepth, texPos, 0).r);
    //if (depth <= 1499) return;

    // Set origin to center pixel
    vec4 pos = invCloudmapViewMatrix * vec4(eyeDirection * depth, 1);
    vec3 cloudspacePos = pos.xyz;

    // Slide position in sun direction to intersect cloud plane
    vec3 cloudmapPos = cloudspacePos + (cloudOffset.y - cloudspacePos.y) * (sunPosition / sunPosition.y);
    cloudmapPos.xz -= cloudOffset.xz;       // Add wind drift
    cloudmapPos /= cloudTileSize;           // Set to pixel scale
    cloudmapPos.xz += ceil(cloudmapSize/2); // Set origin to image origin

    // if cloudmapPos outside cloudmapSize, bail

    vec3 cloudmapUV = vec3(cloudmapPos.xz / cloudmapSize, 0);
    vec4 cloudShadowData = cloudShadowStyle == 0? texelFetch(cloudShadowmap, ivec3(cloudmapPos.xz, 0), 0) : texture(cloudShadowmap, cloudmapUV);

    float cloudDensity = (cloudShadowData.a - cloudShadowData.b) * cloudShadowData.r;
    float cloudThickness = (1 - smoothstep(cloudShadowData.b, cloudShadowData.a, -cloudmapPos.y));

    if (false) {
        texColor += vec4(0, 0, 0, clamp(cloudThickness * cloudDensity, 0f, 0.5));
    }
    */
    if(debug > 0){
        //vec4 cloudmapData = imageLoad(cloudmap, ivec2((gl_FragCoord.xy - ivec2(1500, 0)) / 5));
        //texColor += cloudmapData.a != 0? vec4(cloudmapData.rga, 1) : vec4(0);

        // draw mipmap to screen
        vec4 cloudMipData = imageLoad(cloudmapMip, ivec2((gl_FragCoord.xy - ivec2(800, 880)) / 5));
        texColor += cloudMipData.a != 0? vec4(cloudMipData.rga, 1) : vec4(0);

        // Marching output
		ivec2 mapPosMarch = ivec2((gl_FragCoord.xy - ivec2(0, 30))/2.5);
        mapPosMarch.x = mapPosMarch.x <= 81 * 4? abs(mapPosMarch.x - 81 * 4) : 9999;

        vec4 cloudShadowMapMarch = imageLoad(cloudshadowmarch, mapPosMarch);
        bool hasDataA = (cloudShadowMapMarch.x + cloudShadowMapMarch.y + cloudShadowMapMarch.z) != 0;
        texColor += hasDataA? vec4(log(cloudShadowMapMarch.r)/10, 0, cloudShadowMapMarch.r, 1) : vec4(0);


        // Blur output
		ivec2 mapPosBlur = ivec2((gl_FragCoord.xy - ivec2(1660, 30))/2.5);
        mapPosBlur.x = mapPosBlur.x <= 81 * 4? abs(mapPosBlur.x - 81 * 4) : 9999;

        vec4 cloudShadowMapBlur = imageLoad(cloudshadowmarch, mapPosBlur);
        bool hasDataC = (cloudShadowMapBlur.x + cloudShadowMapBlur.y + cloudShadowMapBlur.z) != 0;
        texColor += hasDataC? vec4(log(cloudShadowMapBlur.r)/10, 0, cloudShadowMapBlur.r, 1) : vec4(0);


        // Final shadowmap
		ivec2 mapPos = ivec2((gl_FragCoord.xy - ivec2(830,30)) / 2.5);
        mapPos.x = mapPos.x <= 81 * 4? abs(mapPos.x - 81 * 4) : 9999;

        vec4 cloudShadowMap = imageLoad(cloudshadowmap, mapPos);
        bool hasDataB = (cloudShadowMap.x + cloudShadowMap.y + cloudShadowMap.z) != 0;
        texColor += hasDataB? vec4(log(cloudShadowMap.r)/10, 0, cloudShadowMap.r, 1) : vec4(0);

        // draw shadowmap to debug
		imageStore(debugtex, texPos, cloudMipData);
        if(hasDataA) imageStore(debugtex, texPos, cloudShadowMapMarch);
        if(hasDataC) imageStore(debugtex, texPos, cloudShadowMapBlur);
		if(hasDataB) imageStore(debugtex, texPos, cloudShadowMap);
    }

}
