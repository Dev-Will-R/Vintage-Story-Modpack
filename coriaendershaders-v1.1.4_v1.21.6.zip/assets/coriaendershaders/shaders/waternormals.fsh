#version 330 core

#define PI 3.14159

// Hash that takes large values and gives 0-1, Copyright (c)2014 David Hoskins https://www.shadertoy.com/view/4djSRW
vec2 hash22(vec2 p)
{
	vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973));
    p3 += dot(p3, p3.yzx+33.33);
    return fract((p3.xx+p3.yz)*p3.zy);
}

in vec3 eyeDirection;

uniform float wavesEnabled;

uniform sampler2D gBufferIn;
uniform mat4 modelViewMatrix;
uniform mat4 invMVMatrix;
uniform vec2 wsWaveRegion;

uniform int specularExponent;

uniform float time;
uniform float cameraUnderwater;
uniform float cameraPitch;
uniform vec3 sunPosition;
uniform float dropletIntensity;

// Writing to read here - fragment must only read it's own position (s9.3.1 OpenGL 4.5)
layout(location = 0) out vec4 gBufferOut;

// Hash one random point per grid unit, return nearest 2 points and the distance to them
vec4 getNearestSources(vec2 p, float gridsize, out vec2 l) {
    vec2 a = round(floor((p + gridsize*vec2( 0.5, 0.5)) / gridsize)*gridsize);
    vec2 b = round(floor((p + gridsize*vec2(-0.5, 0.5)) / gridsize)*gridsize);
    vec2 c = round(floor((p + gridsize*vec2( 0.5,-0.5)) / gridsize)*gridsize);
    vec2 d = round(floor((p + gridsize*vec2(-0.5,-0.5)) / gridsize)*gridsize);

	vec2 e = gridsize * hash22(mod(a, 65503));
	vec2 f = gridsize * hash22(mod(b, 65503));
	vec2 g = gridsize * hash22(mod(c, 65503));
	vec2 h = gridsize * hash22(mod(d, 65503));

	vec2 ae = p - a - e;
	vec2 bf = p - b - f;
	vec2 cg = p - c - g;
	vec2 dh = p - d - h;
    vec4 x = vec4(ae.x, bf.x, cg.x, dh.x);
    vec4 y = vec4(ae.y, bf.y, cg.y, dh.y);

    vec4 lengths = vec4(
        length(ae),
        length(bf),
        length(cg),
        length(dh)
    );

    // Find shortest 2
    if(lengths.x < lengths.y) { lengths = lengths.yxzw; x = x.yxzw; y = y.yxzw; }
    if(lengths.z < lengths.w) { lengths = lengths.xywz; x = x.xywz; y = y.xywz; }
    if(lengths.x < lengths.w) { lengths = lengths.wyzx; x = x.wyzx; y = y.wyzx; }
    if(lengths.y < lengths.z) { lengths = lengths.xzyw; x = x.xzyw; y = y.xzyw; }
    if(lengths.z < lengths.w) { lengths = lengths.xywz; x = x.xywz; y = y.xywz; }

    l = vec2(lengths.w, lengths.z);
    return vec4(x.w, y.w, x.z, y.z);
}

float wavedh(float x) {
    return pow(sin(PI * sqrt(x - floor(x))), 2) - abs(0.3 * sin(PI*x)) + 0.1;
}

// Get nearest two waves and blend
vec2 distanceWaves(vec2 p, float gridsize, float frequency, float speed, float amplitude, float start, float end, vec2 dx) {
    vec2 lengths;
    vec4 sources = getNearestSources(p + dx, gridsize, lengths);
    float x1 = lengths.x * frequency - time * speed * frequency;
    float x2 = lengths.y * frequency - time * speed * frequency;
    float i = smoothstep(start, start + 1/frequency, lengths.x);
    float j = smoothstep(start, start + 1/frequency, lengths.y);
    float k = smoothstep(-0.5*end, 0.5*end, lengths.x - lengths.y);
    float dh = amplitude * mix(i*wavedh(x1), j*wavedh(x2), k);
    vec2 sourceNormal = normalize(mix(sources.xy, sources.zw, k));
	vec2 dxz = sourceNormal * dh;

    return dxz;
}

float rainwavedh(float x) {
    return 0.7*(cos(20*x) + 9*cos(5*x)+3*cos(200*x)-11);
}

vec2 rainWaves(vec2 p, float gridsize, vec2 dx) {
	vec2 lengths;
    vec2 driftingPos = p + 0.4*time + dx;
	vec4 sources = getNearestSources(driftingPos, gridsize, lengths);
    float t = time + 100*hash22(floor(sources.xy - driftingPos)).x;
	float x1 = lengths.x - t;
    float fade = 1-smoothstep(0, 0.4, lengths.x);
	float collide = smoothstep(0, 0.1, lengths.y - lengths.x);
    float dh = fade*collide*rainwavedh(x1);
    dh = dh > 0? dh : 0;
    return normalize(sources.xy) * dh;
}

/* gBuffer In
rgb - world space "view" vector
a - camera space depth; 0: do not draw; sign: skyExposed
NOTE - OIT blends additively, g channel is count of layers
*/
void main() {
    vec4 gBufferData = texelFetch(gBufferIn, ivec2(gl_FragCoord.xy), 0);
    if(gBufferData.a == 0) { discard; } // Not water
    // Average OIT layers. Should only matter at great distances.
    gBufferData /= abs(gBufferData.g);
    float skyExposed = gBufferData.a > 0? 1 : -1;
    vec3 csPosition = eyeDirection * abs(gBufferData.a);
    vec2 wsPosition = (invMVMatrix * vec4(csPosition, 1)).xz;
    float underwater = cameraUnderwater > 0.7? -1 : 1;

    #if CS_UNDERWATER_ENABLED == 0
    if(underwater == -1)
    {
        gl_FragDepth = 1;
        return;
    }
    #endif

    float distanceFromPlayer = length(wsPosition);
    vec2 waveRegionPos = wsPosition + wsWaveRegion;
    vec3 wsNormal = vec3(0,1,0);

    vec2 waveDerivatives = vec2(0);
    if(wavesEnabled == 1) {
        //distanceWaves(p, gridsize, frequency, speed, amplitude, start lag, end lag, dx)
        waveDerivatives +=  distanceWaves(waveRegionPos, 2113, 0.05, 2, 0.02, 40, 40, vec2(0));
	    waveDerivatives +=  distanceWaves(waveRegionPos, 1024, 0.1, 1.5, 0.02, 40, 40, waveDerivatives * 10);
        vec2 wvA =  distanceWaves(waveRegionPos, 128, 0.5, 1, 0.04, 40, 30, waveDerivatives * 50);
	    waveDerivatives +=  distanceWaves(waveRegionPos, 96, 0.8, 0.9, 0.04, 40, 30, waveDerivatives * 32 + wvA * 10);
        waveDerivatives += wvA;
    }
    // Raindrops
    vec2 lightRain = dropletIntensity > 0.05 && skyExposed > 0 && distanceFromPlayer < 80? rainWaves(waveRegionPos, max(-15*dropletIntensity + 4.75, 1), vec2(0)) : vec2(0);
    vec2 heavyRain= dropletIntensity > 0.5 && skyExposed > 0 && distanceFromPlayer < 80? rainWaves(waveRegionPos + vec2(50), max(-15*dropletIntensity + 11.5, 1), vec2(0)) : vec2(0);
    waveDerivatives += lightRain;
    waveDerivatives += heavyRain;
    float rainy = lightRain.x + lightRain.y + heavyRain.x + heavyRain.y != 0? 1 : 0;

    vec3 t = vec3(1, waveDerivatives.x, 0);
	vec3 b = vec3(0, waveDerivatives.y, 1);
	vec3 n = cross(b,t);
    wsNormal = normalize(vec3(n.x, underwater, n.z));

    vec3 wsViewDir = -normalize(gBufferData.rgb);
    vec3 csReflectionDirection = normalize((modelViewMatrix * vec4(reflect(-wsViewDir, wsNormal), 0)).xyz);

    // Define a degree range <32, squashes fresnel values under ~0.027
    int fresnelTheta = int(clamp(degrees(acos(dot(wsViewDir, wsNormal))), 58, 89) - 58);

    // Pretend we're always above the water for specular math
    wsViewDir.y *= underwater;
    wsNormal.y *= underwater;
    vec3 h = normalize(wsViewDir + sunPosition);
    // Specular effect fades out before 1 radian, so just clamp it to the fractional part.
    float specularTheta = sunPosition.y > 0? clamp(acos(dot(wsNormal, h)), 0, 0.9) : 0.999;
    float packedThetas = fresnelTheta + fract(specularTheta);

    /* gBuffer Out
    r - REPLACE: reflection normal x
    g - REPLACE: fract: reflection normal y, integral==1: is a rain ripple
    b - ADD: integral: fresnel angle-58, fractal: specular angle in radians, sign: sky exposed
    a - REPLACE: sign(reflection normal z)
    */
    gBufferOut= vec4(
		csReflectionDirection.x,
        // Storing rain this way causes precision loss, but precision is less important on rain ripples
		clamp(csReflectionDirection.y, -0.9999, 0.9999) + sign(csReflectionDirection.y) * rainy,
		skyExposed * packedThetas,
		sign(csReflectionDirection.z) * abs(gBufferData.a)
	);

    // Use early depth test to skip SSR
    if(csReflectionDirection.z > 0 || wsNormal.y <= 0 || cameraUnderwater > 0.7 || rainy < 0) {
        gl_FragDepth = 1;
    } else {
        gl_FragDepth = 0;
    }
}
