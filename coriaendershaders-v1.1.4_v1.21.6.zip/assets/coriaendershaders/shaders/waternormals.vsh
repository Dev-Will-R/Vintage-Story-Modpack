#version 330

layout(location=0) in vec3 xyz;
layout(location=1) in vec2 uv;

uniform vec2 halfSizeNearPlane;

out vec3 eyeDirection;

void main()
{
    gl_Position = vec4(xyz, 1);

    // Calculate eye space direction  (https://wikis.khronos.org/opengl/Compute_eye_space_from_window_space)
    eyeDirection = vec3((2.0 * halfSizeNearPlane * uv) - halfSizeNearPlane, -1.0);
}
