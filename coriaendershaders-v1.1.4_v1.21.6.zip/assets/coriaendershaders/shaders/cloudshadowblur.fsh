#version 330 core

// No filtering 9-tap
//const int stepCount = 5;
//const float[5] offset = float[](0f, 1f, 2f, 3f, 4f);
//const float[5] weight = float[](0.2270270270, 0.1945945946, 0.1216216216, 0.0540540541, 0.0162162162);

// Filtering 9-tap
//const int stepCount = 3;
//const float[3] offset = float[](0f, 1.3846153846, 3.2307692308);
//const float[3] weight = float[](0.2270270270, 0.3162162162, 0.0702702703);

// Filtering 7-tap
const int stepCount = 2;
const float[2] offset = float[](0.53804, 2.06278);
const float[2] weight = float[](0.44908, 0.05092);

uniform float invLength; // 1 / length of this axis
uniform int axis;

in vec2 vUV;
uniform sampler2D sourceTexture;
uniform vec2 readOffset;
uniform int cloudShadowStyle;
layout(location = 0) out vec4 texColor;

vec4 gaussianBlur(sampler2D targetTexture, vec2 uv, int workingAxis){
    // For 9-tap, get center pixel first then start loop at i=1
    //vec4 color = texture2D(targetTexture, pos * invLength) * weight[0];
    vec4 color = vec4(0);
    for (int i=0; i<stepCount; i++) {
        vec2 offset = invLength * (workingAxis == 0? vec2(offset[i], 0) : vec2(0, offset[i]));
        color += texture(targetTexture, uv + offset) * weight[i];
        color += texture(targetTexture, uv - offset) * weight[i];
    }    
    return color;
}

void main() {
    texColor = cloudShadowStyle == 0? texture(sourceTexture, vUV - readOffset) : gaussianBlur(sourceTexture, vUV - readOffset, axis);
}
