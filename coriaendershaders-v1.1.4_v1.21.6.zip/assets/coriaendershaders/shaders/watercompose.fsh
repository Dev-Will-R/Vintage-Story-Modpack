#version 330

in vec3 eyeDirection;

uniform float skyboxReflectionsEnabled;

uniform sampler2DShadow shadowMapFar;
uniform sampler2D gBufferIn;
uniform sampler2D cameraDepth;
uniform sampler2D mainColor;
uniform sampler2D glowColor;
uniform samplerCube skyCubeMap;
uniform float reflectionStrength;

uniform float daylight;
uniform vec3 sunColor;
uniform vec3 sunPosition;
uniform float cameraUnderwater;
uniform float viewDistance;
uniform ivec2 screenSize;
uniform mat4 invModelViewMatrix;
uniform mat4 cstoshadowMatrix;
uniform mat4 pixelMVPMatrix;

uniform vec3 waterMurkinessColor; // = vec3(0.05752, 0.19962, 0.17963);

layout(location=0) out vec4 texColor;

/* gBuffer Input
rg - reflection normal x,y || SSR pixel coord x,y (if hit); g integral==1: is rain ripple
b - integral: fresnel angle-58, fractal: specular angle in radians, sign: sky exposed
a - camera space depth; 0: do not draw; sign: sign(reflection normal z)
*/
void main() {
    vec2 UV = gl_FragCoord.xy / screenSize;
    float underwater = cameraUnderwater > 0.7? 1 : 0;
    #if CS_UNDERWATER_ENABLED == 0
    if(underwater == 1) { discard; }
    #endif

    vec4 gBufferData = texelFetch(gBufferIn, ivec2(gl_FragCoord.xy), 0);
    if(gBufferData.a == 0) { discard; } // Not water

    float fresnelTheta = radians(floor(abs(gBufferData.b)) + 58);
    float specularTheta = fract(abs(gBufferData.b));

    bool ssrHit = gBufferData.r > 1 || gBufferData.g > 2;
    ivec2 ssrPixelHit = ssrHit? ivec2(gBufferData.rg) : ivec2(0);

    vec3 csPosition = eyeDirection * abs(gBufferData.a);
    vec3 wsPosition = (invModelViewMatrix * vec4(csPosition,0)).xyz;
    vec3 wsNorm = normalize(wsPosition);
    vec4 shadowSpacePosition = cstoshadowMatrix * vec4(csPosition, 1);
    float sunVisible = textureProj(shadowMapFar, shadowSpacePosition);
    float distanceToPlayer = length(wsPosition.xz);
    //float waterDepth = -csPosition.z - texelFetch(cameraDepth, ivec2(gl_FragCoord.xy), 0).r;

    bool skyHit = !ssrHit && (sunVisible == 1 || sign(gBufferData.b) > 0);
    float csDirY = fract(abs(gBufferData.g)) * sign(gBufferData.g);
	float z = skyHit? sqrt(1 - pow(gBufferData.r, 2) - pow(csDirY, 2)) * sign(gBufferData.a) : 0;
    vec3 csReflectionDir = vec3(gBufferData.r, csDirY, z);
	vec3 skyViewDirection = skyHit? (invModelViewMatrix * vec4(csReflectionDir, 0)).xyz : vec3(0);

    // Underwater refraction. Refraction looking into water would require replacing the water rendering entirely
    // Math fails at very shallow depths, so fake it for the first ~0.4
    float sceneDepth = underwater > 0? texelFetch(cameraDepth, ivec2(gl_FragCoord.x, gl_FragCoord.y *(1-0.05*smoothstep(0,1,wsPosition.y))), 0).r : -4;
    bool refractionHit = (sceneDepth > -csPosition.z - 1 && sceneDepth < viewDistance) || underwater * length(wsPosition.xz) > 30? true : false;
    if(!refractionHit && wsPosition.y > 0.4 && length(wsPosition.xz) > 2) {
		vec3 a = 1.02*(wsNorm + skyViewDirection)/2;
		vec3 b = -sqrt(1 - pow(length(a),2))*(skyViewDirection-wsNorm)/(2*cos(fresnelTheta));
		vec3 wsRefractionDir = a + b;
        vec4 refractionPixelPos = pixelMVPMatrix * vec4(wsRefractionDir * viewDistance, 0);
        ivec2 refractionPixel = ivec2(refractionPixelPos.xy / refractionPixelPos.w);
        refractionPixel.x = min(max(refractionPixel.x, 0), screenSize.x-1);
        refractionPixel.y = min(max(refractionPixel.y, 0), screenSize.y-1);
        float refractDepth = texelFetch(cameraDepth, refractionPixel, 0).r;
        refractionHit = (refractDepth > 0 - 1 && refractDepth < viewDistance);
    }
    skyViewDirection.y *= sign(skyViewDirection.y);
    if(!ssrHit && skyViewDirection.y <= 0 && !refractionHit) { discard; }

    texColor = ssrHit? texelFetch(mainColor, ssrPixelHit, 0)
             : refractionHit? vec4(mix(texture(mainColor, UV).xyz, waterMurkinessColor, smoothstep(0,1,wsPosition.y)), 1)
             : skyboxReflectionsEnabled == 1 && skyHit? vec4(texture(skyCubeMap, skyViewDirection).xyz, 1)
             : vec4(texture(mainColor, UV).xyz, 1);

    texColor = vec4(mix(texColor.rgb, waterMurkinessColor, 0.4 * underwater), 1);

    // Don't reflect darkness
	if(texColor.r + texColor.g + texColor.b < 0.01) discard;

    // Get a more generic sky color to help with having the reflection better match the perceived sky
    vec3 skyColor = texture(skyCubeMap, 0.5*(wsNorm + vec3(0,1,0))).xyz;
    skyColor = skyHit? mix(skyColor, texColor.rgb, 0.9) : skyColor;
    float cloudCover = smoothstep(0., 0.75, 1 - skyColor.g/max(skyColor.b, skyColor.r));
    float hitGlow = texelFetch(glowColor, ssrPixelHit, 0).r;

    // Color and lighting
    bool rainy = !ssrHit && abs(gBufferData.g) >= 1;
    float fresnel = pow(1 - cos(fresnelTheta), 5);
    float sunSpecular = sunVisible == 1 && specularTheta >= 0? pow(cos(specularTheta), underwater < 0? 900 : 10 + 170 * smoothstep(0.01, 0.4, sunPosition.y)) : 0;
    if(underwater < 1) {
        // Fresnel effect
        texColor.rgb += sunVisible == 1? daylight * smoothstep(0.6, 1.8, fresnel) : 0;
        // Darken shadows, scaled up with daylight and ignored if the reflection is glowing
        texColor.rgb *= sunVisible != 1 || hitGlow > 0.1? 1 - 0.2 * smoothstep(0.5, 1, daylight) : 1;
		texColor.a *= sunVisible == 1? 0.5 + fresnel : 0.4;
        // Clamp blue to green so sky blue doesn't overwhelm water color
        texColor.b -= skyHit? clamp(texColor.b - texColor.g, 0, 1) * 0.5 : 0;
        // Clamp all colors so reflections never seem brighter than the sky. 
        float tintLimit = max(max(max(skyColor.r, skyColor.g), skyColor.b), hitGlow);
        texColor.rgb = min(texColor.rgb, daylight > 0.5? tintLimit : 1);
        // Sun specular
        texColor.rgb += sunSpecular*sunColor*(0.8+3*smoothstep(0, 180, distanceToPlayer))*cloudCover;
		texColor.a += 2*sunSpecular + smoothstep(0.4, 1.3, sunSpecular)*cloudCover;
        // Give the stars a little boost
        texColor.a *= skyHit && !rainy? 1 + 2 * (1 - smoothstep(0.3, 0.5, daylight)) : 1;
        // Exaggerate raindrops
        texColor.rgb += rainy? tintLimit*(0.5 + 0.5*smoothstep(0, 25, distanceToPlayer)) : 0;
		texColor.a += rainy? 0.2 : 0;
	} else {
        // Fade to murk based on depth and distance. Use fresnel for distance so the waves are visible.
        vec3 depthColor = waterMurkinessColor  * vec3(0.5, 0.9, 0.9) * smoothstep(-25, -3, -wsPosition.y);
        texColor.rgb = mix(texColor.rgb, depthColor, smoothstep(-0.1, 0.2,fresnel*smoothstep(2, 10, wsPosition.y)));
		texColor.b -= clamp(texColor.b - texColor.g, 0, 1) * 0.3;
        texColor.a *= smoothstep(-20, -10, -wsPosition.y);
        // Sun specular
        texColor.rgb += daylight*sunSpecular*mix(sunColor,waterMurkinessColor,0.6);
    }

    // If hit glowing, increase alpha.
    texColor.a *= ssrHit? 1 + 1.5 * hitGlow : 1;
    // If drawing over glow, decrease alpha.
    texColor.a *= 1 - texture(glowColor, UV).r;

    texColor.a *= underwater > 0? 1 : reflectionStrength;
}
