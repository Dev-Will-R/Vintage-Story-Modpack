# Coriaender Shaders
This is my shader mod for adding visual effects to the game. I'm new to both graphics programming and modding, so please let me know if you run into any issues.
## Features
### Water Surface Shader
* Layers visual effects onto surface water. Some general lighting such as fresnel and specular effects, as well as reflection systems and a randomized wave system.  
	* Skybox reflections
		* Uses a cubemap to add reflections of the sky from any direction.
	* Screen space reflections
		* Uses ray marching to reflect everything else, but is limited to what's visible on screen. Settings allow for balancing fidelity and performance.
### Cloud Shadows
* Builds a shadow map based on the clouds for the game to reference when adding shadows.
## Compatibility & Dependency
The mod was developed on v1.26.6, but isn't dependent on anything specific to that version. Older versions might work but haven't been tested.

The cloud shadows uses compute shaders since I wanted to practice with them, which means it requires a newer version of OpenGL than the base game. Not too much newer, but if your graphics card is more than ~15 years old it might not support it.

Using the settings UI requires the mod [VSImGUI](https://mods.vintagestory.at/imgui) be installed, but it isn't required and the settings can be changed in the modconfig directly.

This mod makes changes to many of the game's base shaders by replacing code at run time. This should be mostly resilient to other mods as long as they don't disable the base game shaders entirely, but it uses pattern matching so could fail if specific lines are changed.
## Settings
The following settings can be changed in the modconfig file (\VintagestoryData\ModConfig\CoriaenderShaders.json) or by opening the UI in game. To reset settings to defaults, delete the config file.
* SettingsGUIHotkey
	* Default K
	* Hotkey for opening settings GUI if VSImGUI is installed. Can only be changed in the config file, not in game.
* WaterEffectsEnabled
	* Enable/disable all water and reflection effects.
* reflectionStrength
	* Default 0.3
	* Directly adjust final alpha (visibility) of effects.
* SkyboxReflectionsEnabled
	* Reflect the sky and clouds.
* WavesEnabled
	* Simulate waves on the water surface.
* SSREnabled
	* Reflect the scene based on what is on screen.
* SSR Settings
    * SSREdgeAdjustEnabled 
	    * As the camera is pitched down the perspective shift causes some SSR rays near the edge of the screen to miss, and the abrupt transition to sky can be very noticeable. This pulls SSR to the edge a bit to cover that contrast, but doing so causes some sliding motion, so you can turn that off here if you prefer. No effect on performance.
	* Stride
	    * Default 2
		* How many pixels between samples while ray marching SSR. Increasing value will progressively introduce noise and banding but will greatly improving performance, with diminishing returns.
	* maxSteps
		* Set to -1 to default to screen width.
		* The max pixel length of each ray for SSR. Most rays don't travel the full distance, so only a marginal effect on performance. 
	*	maxDistance
		* Set to -1 to default to twice the draw distance.
		* The max world space length of each ray for SSR. Low values can give a small performance improvement by removing most reflections, but rays are clipped to the view distance so a higher value won't change performance.
* ShadowEffectsEnabled
  * Enable/disable all shadow effects.
* CloudShadowsEnabled
  * Cast cloud shadows. The only shadow effect currently.
* CloudShadowStyle = 1
  * Whether to blur shadows (1) or not (0).
* CloudShadowMax = 0.4
  * Default 40%
  * The darkest cloud shadows can get, from 0 (no shadows) to 1 (complete darkness).
* TerrainShadowsEnabled
  * A work in progress, this setting does nothing for now.
## Known Issues
Fixes or improvements I'd like to implement but have not.
* Reflecting the moon is not implemented
  * The sun reflection is only based on the sun position, but the moon requires a texture so is more complicated.
* Reflections are drawn over transparent objects
  * The mod doesn't use the game's OIT "revealage" because it is shared between water and transparent objects, meaning I need to build out a process for tracking transparent revealage independently.
* There is color banding on the sun specular reflection
  * Adding some dithering will make this look better.

